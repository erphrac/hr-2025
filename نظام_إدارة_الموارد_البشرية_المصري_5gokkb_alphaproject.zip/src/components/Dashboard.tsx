import React from 'react';
import { 
  Users, Clock, DollarSign, Calendar, TrendingUp, 
  AlertTriangle, CheckCircle, XCircle, Plus, FileText 
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { mockEmployees, mockAttendance, mockPayroll, mockNotifications, mockProjects } from '../data/mockData';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  // Calculate statistics
  const totalEmployees = mockEmployees.length;
  const activeEmployees = mockEmployees.filter(emp => emp.isActive).length;
  const presentToday = mockAttendance.filter(att => att.status === 'حاضر' || att.status === 'متأخر').length;
  const absentToday = mockAttendance.filter(att => att.status === 'غائب').length;
  const attendanceRate = Math.round((presentToday / totalEmployees) * 100);
  
  const totalPayroll = mockPayroll.reduce((sum, pay) => sum + pay.netSalary, 0);
  const avgSalary = Math.round(totalPayroll / mockPayroll.length);
  
  const activeProjects = mockProjects.filter(p => p.status === 'نشط').length;
  const completedProjects = mockProjects.filter(p => p.status === 'مكتمل').length;
  const totalBudget = mockProjects.reduce((sum, p) => sum + p.budget, 0);
  const totalExpenses = mockProjects.reduce((sum, p) => sum + p.expenses, 0);

  // Recent activities data
  const recentActivities = [
    { activity: 'تسجيل دخول محمد أحمد', details: 'قسم الهندسة', time: 'منذ 5 دقائق' },
    { activity: 'إضافة موظف جديد: سارة محمود', details: 'قسم العمالة', time: 'منذ 15 دقيقة' },
    { activity: 'تأخير في الحضور: أحمد علي', details: 'قسم اللوجستيات', time: 'منذ 30 دقيقة' },
    { activity: 'اكتمال كشف رواتب أغسطس', details: 'جميع الأقسام', time: 'منذ ساعة' },
  ];

  // Chart data
  const attendanceData = [
    { name: 'حاضر', value: presentToday, color: '#10b981' },
    { name: 'غائب', value: absentToday, color: '#ef4444' },
    { name: 'متأخر', value: mockAttendance.filter(att => att.status === 'متأخر').length, color: '#f59e0b' },
  ];

  const departmentData = [
    { dept: 'الهندسة', employees: 15, budget: 1200 },
    { dept: 'العمالة', employees: 25, budget: 800 },
    { dept: 'اللوجستيات', employees: 10, budget: 600 },
    { dept: 'المحاسبة', employees: 6, budget: 400 },
    { dept: 'الإدارة', employees: 8, budget: 500 },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">لوحة التحكم الرئيسية</h1>
          <p className="text-gray-600 mt-1">نظرة عامة على نشاط الشركة - الجمعة 23 أغسطس 2025</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3 space-x-reverse">
          <button onClick={() => onNavigate('employees')} className="btn-primary flex items-center">
            <Plus className="h-4 w-4 ml-2" />
            إضافة موظف
          </button>
          <button onClick={() => onNavigate('reports')} className="btn-secondary flex items-center">
            <FileText className="h-4 w-4 ml-2" />
            تقرير سريع
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">إجمالي الموظفين</p>
              <p className="text-3xl font-bold text-gray-900">{totalEmployees}</p>
              <p className="text-sm text-emerald-600 mt-1">
                <span className="inline-flex items-center">
                  <TrendingUp className="h-4 w-4 ml-1" />
                  +5% عن الشهر الماضي
                </span>
              </p>
            </div>
            <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
              <Users className="h-6 w-6 text-primary-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">معدل الحضور اليوم</p>
              <p className="text-3xl font-bold text-gray-900">{attendanceRate}%</p>
              <p className="text-sm text-gray-600 mt-1">{presentToday} من {totalEmployees} موظف</p>
            </div>
            <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center">
              <Clock className="h-6 w-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">إجمالي الرواتب</p>
              <p className="text-3xl font-bold text-gray-900">{(totalPayroll / 1000000).toFixed(1)}م ج.م</p>
              <p className="text-sm text-gray-600 mt-1">متوسط {avgSalary.toLocaleString()} ج.م</p>
            </div>
            <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-amber-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">المشاريع النشطة</p>
              <p className="text-3xl font-bold text-gray-900">{activeProjects}</p>
              <p className="text-sm text-gray-600 mt-1">{completedProjects} مكتمل</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activities & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">الأنشطة الأخيرة</h3>
            <div className="flex space-x-2 space-x-reverse">
              <button className="text-sm text-primary-600 hover:text-primary-700">اليوم</button>
              <button className="text-sm text-gray-500 hover:text-gray-700">الأسبوع</button>
              <button className="text-sm text-gray-500 hover:text-gray-700">الشهر</button>
            </div>
          </div>
          
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3 space-x-reverse p-3 rounded-lg hover:bg-gray-50">
                <div className="h-2 w-2 bg-primary-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.activity}</p>
                  <p className="text-sm text-gray-600">{activity.details}</p>
                </div>
                <span className="text-xs text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">إجراءات سريعة</h3>
          <div className="space-y-3">
            <button onClick={() => onNavigate('employees')} className="w-full p-3 text-right bg-primary-50 hover:bg-primary-100 rounded-lg transition-colors duration-200">
              <div className="flex items-center">
                <Plus className="h-5 w-5 text-primary-600 ml-3" />
                <span className="text-primary-700 font-medium">إضافة موظف جديد</span>
              </div>
            </button>
            
            <button onClick={() => onNavigate('attendance')} className="w-full p-3 text-right bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors duration-200">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-emerald-600 ml-3" />
                <span className="text-emerald-700 font-medium">تسجيل حضور</span>
              </div>
            </button>
            
            <button onClick={() => onNavigate('payroll')} className="w-full p-3 text-right bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors duration-200">
              <div className="flex items-center">
                <DollarSign className="h-5 w-5 text-amber-600 ml-3" />
                <span className="text-amber-700 font-medium">حساب الرواتب</span>
              </div>
            </button>
            
            <button onClick={() => onNavigate('reports')} className="w-full p-3 text-right bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors duration-200">
              <div className="flex items-center">
                <FileText className="h-5 w-5 text-blue-600 ml-3" />
                <span className="text-blue-700 font-medium">تقرير شهري</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Notifications & Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Notifications */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">التنبيهات والإشعارات</h3>
            <span className="text-sm text-gray-500">{mockNotifications.filter(n => !n.isRead).length} جديد</span>
          </div>
          
          <div className="space-y-3">
            {mockNotifications.slice(0, 4).map((notification) => (
              <div key={notification.id} className={`p-3 rounded-lg border-r-4 ${
                notification.type === 'warning' ? 'bg-amber-50 border-amber-400' :
                notification.type === 'error' ? 'bg-red-50 border-red-400' :
                notification.type === 'success' ? 'bg-emerald-50 border-emerald-400' :
                'bg-blue-50 border-blue-400'
              }`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{notification.title}</p>
                    <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                  </div>
                  <div className="mr-3">
                    {notification.type === 'warning' && <AlertTriangle className="h-5 w-5 text-amber-500" />}
                    {notification.type === 'error' && <XCircle className="h-5 w-5 text-red-500" />}
                    {notification.type === 'success' && <CheckCircle className="h-5 w-5 text-emerald-500" />}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Attendance Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">إحصائيات الحضور اليوم</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {attendanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Department Overview */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">نظرة عامة على الأقسام</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={departmentData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="dept" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="employees" fill="#0ea5e9" name="عدد الموظفين" />
              <Bar dataKey="budget" fill="#10b981" name="الميزانية (ألف ج.م)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Project Status */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">حالة المشاريع</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{activeProjects}</div>
            <div className="text-sm text-blue-700">مشاريع نشطة</div>
          </div>
          <div className="text-center p-4 bg-emerald-50 rounded-lg">
            <div className="text-2xl font-bold text-emerald-600">{completedProjects}</div>
            <div className="text-sm text-emerald-700">مشاريع مكتملة</div>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-600">{(totalBudget / 1000000).toFixed(1)}م</div>
            <div className="text-sm text-gray-700">إجمالي الميزانيات (ج.م)</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

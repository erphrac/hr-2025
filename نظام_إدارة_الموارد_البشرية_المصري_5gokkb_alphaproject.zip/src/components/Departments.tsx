import React, { useState } from 'react';
import { Building2, Plus, Edit, Trash2, Users } from 'lucide-react';
import { mockDepartments, mockEmployees } from '../data/mockData';
import { Department } from '../types';

const Departments: React.FC = () => {
  const [departments, setDepartments] = useState<Department[]>(mockDepartments);
  const [showModal, setShowModal] = useState(false);
  const [currentDepartment, setCurrentDepartment] = useState<Partial<Department> | null>(null);

  const handleAdd = () => {
    setCurrentDepartment({});
    setShowModal(true);
  };

  const handleEdit = (dept: Department) => {
    setCurrentDepartment(dept);
    setShowModal(true);
  };

  const handleSave = () => {
    // In a real app, this would be an API call
    if (currentDepartment?.id) {
      setDepartments(departments.map(d => d.id === currentDepartment.id ? currentDepartment as Department : d));
    } else {
      // Add new department logic
      const newDept = { ...currentDepartment, id: (departments.length + 1).toString(), employeeCount: 0 } as Department;
      setDepartments([...departments, newDept]);
    }
    setShowModal(false);
    setCurrentDepartment(null);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">إدارة الأقسام</h1>
          <p className="text-gray-600 mt-1">عرض وتعديل الهيكل التنظيمي للشركة</p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button onClick={handleAdd} className="btn-primary flex items-center">
            <Plus className="h-4 w-4 ml-2" />
            إضافة قسم جديد
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map(dept => (
          <div key={dept.id} className="card hover:shadow-lg transition-shadow duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="p-3 bg-primary-100 rounded-lg">
                  <Building2 className="h-6 w-6 text-primary-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{dept.name}</h3>
                  <p className="text-sm text-gray-500">رئيس القسم: {dept.head}</p>
                </div>
              </div>
              <div className="flex space-x-1 space-x-reverse">
                <button onClick={() => handleEdit(dept)} className="p-2 text-gray-500 hover:text-amber-600 rounded-full hover:bg-amber-100">
                  <Edit className="h-4 w-4" />
                </button>
                <button className="p-2 text-gray-500 hover:text-red-600 rounded-full hover:bg-red-100">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="flex justify-between items-center text-sm text-gray-700">
              <div className="flex items-center">
                <Users className="h-4 w-4 ml-2 text-gray-400" />
                <span>{dept.employeeCount} موظف</span>
              </div>
              <div className="flex items-center">
                <span className="font-semibold ml-1">الميزانية:</span>
                <span>{dept.budget.toLocaleString()} ج.م</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg">
            <h2 className="text-xl font-bold text-gray-900 mb-4">{currentDepartment?.id ? 'تعديل القسم' : 'إضافة قسم جديد'}</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">اسم القسم</label>
                <input
                  type="text"
                  className="input-field mt-1"
                  defaultValue={currentDepartment?.name}
                  placeholder="مثال: قسم الشؤون المالية"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">رئيس القسم</label>
                <select className="input-field mt-1" defaultValue={currentDepartment?.head}>
                  <option>اختر رئيس القسم</option>
                  {mockEmployees.map(emp => <option key={emp.id} value={emp.fullName}>{emp.fullName}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">الميزانية (ج.م)</label>
                <input
                  type="number"
                  className="input-field mt-1"
                  defaultValue={currentDepartment?.budget}
                  placeholder="500000"
                />
              </div>
              <div className="flex justify-end space-x-3 space-x-reverse pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">إلغاء</button>
                <button type="button" onClick={handleSave} className="btn-primary">حفظ</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Departments;

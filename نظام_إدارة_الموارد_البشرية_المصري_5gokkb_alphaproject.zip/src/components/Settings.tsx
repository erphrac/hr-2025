import React, { useState } from 'react';
import { Shield, Bell, Users, Save } from 'lucide-react';

const Settings: React.FC = () => {
  const [law2025Enabled, setLaw2025Enabled] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">الإعدادات</h1>
        <p className="text-gray-600 mt-1">إدارة إعدادات النظام والتفضيلات العامة.</p>
      </div>

      {/* Legal & Compliance Settings */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Shield className="h-6 w-6 text-primary-600 ml-3" />
          <h2 className="text-xl font-semibold text-gray-800">الإعدادات القانونية والامتثال</h2>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-800">تفعيل قانون العمل المصري الجديد رقم 14 لسنة 2025</p>
              <p className="text-sm text-gray-500">
                سيقوم النظام بتطبيق جميع الحسابات المتعلقة بالإجازات، التأمينات، وساعات العمل الإضافية وفقاً للقانون الجديد.
              </p>
            </div>
            <label htmlFor="law-toggle" className="flex items-center cursor-pointer">
              <div className="relative">
                <input 
                  type="checkbox" 
                  id="law-toggle" 
                  className="sr-only" 
                  checked={law2025Enabled}
                  onChange={() => setLaw2025Enabled(!law2025Enabled)}
                />
                <div className={`block w-14 h-8 rounded-full ${law2025Enabled ? 'bg-primary-600' : 'bg-gray-300'}`}></div>
                <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${law2025Enabled ? 'transform translate-x-full' : ''}`}></div>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Bell className="h-6 w-6 text-primary-600 ml-3" />
          <h2 className="text-xl font-semibold text-gray-800">إعدادات الإشعارات</h2>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-gray-700">إشعارات البريد الإلكتروني</p>
            <label htmlFor="email-toggle" className="flex items-center cursor-pointer">
              <div className="relative">
                <input type="checkbox" id="email-toggle" className="sr-only" checked={emailNotifications} onChange={() => setEmailNotifications(!emailNotifications)} />
                <div className={`block w-14 h-8 rounded-full ${emailNotifications ? 'bg-primary-600' : 'bg-gray-300'}`}></div>
                <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${emailNotifications ? 'transform translate-x-full' : ''}`}></div>
              </div>
            </label>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-gray-700">إشعارات الرسائل القصيرة (SMS)</p>
            <label htmlFor="sms-toggle" className="flex items-center cursor-pointer">
              <div className="relative">
                <input type="checkbox" id="sms-toggle" className="sr-only" checked={smsNotifications} onChange={() => setSmsNotifications(!smsNotifications)} />
                <div className={`block w-14 h-8 rounded-full ${smsNotifications ? 'bg-primary-600' : 'bg-gray-300'}`}></div>
                <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${smsNotifications ? 'transform translate-x-full' : ''}`}></div>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* User Management Placeholder */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Users className="h-6 w-6 text-primary-600 ml-3" />
          <h2 className="text-xl font-semibold text-gray-800">إدارة المستخدمين والصلاحيات</h2>
        </div>
        <p className="text-gray-600">هنا يمكنك إدارة حسابات المستخدمين وتحديد صلاحيات الوصول لكل دور وظيفي.</p>
        <button className="btn-secondary mt-4">إدارة المستخدمين</button>
      </div>

      <div className="flex justify-end pt-4">
        <button className="btn-primary flex items-center">
          <Save className="h-4 w-4 ml-2" />
          حفظ التغييرات
        </button>
      </div>
    </div>
  );
};

export default Settings;

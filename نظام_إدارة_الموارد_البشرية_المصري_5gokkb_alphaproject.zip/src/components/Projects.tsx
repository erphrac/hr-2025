import React, { useState } from 'react';
import { 
  Plus, BarChart3, Calendar, DollarSign, Users, 
  AlertTriangle, CheckCircle, Clock, Edit, Eye, Play
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { mockProjects } from '../data/mockData';
import { Project, ProjectTask } from '../types';

const Projects: React.FC = () => {
  const [projects] = useState<Project[]>(mockProjects);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showGanttChart, setShowGanttChart] = useState(false);

  // Calculate statistics
  const activeProjects = projects.filter(p => p.status === 'نشط').length;
  const completedProjects = projects.filter(p => p.status === 'مكتمل').length;
  const onHoldProjects = projects.filter(p => p.status === 'متوقف').length;
  const totalBudget = projects.reduce((sum, p) => sum + p.budget, 0);
  const totalExpenses = projects.reduce((sum, p) => sum + p.expenses, 0);
  const avgProgress = Math.round(projects.reduce((sum, p) => sum + p.progress, 0) / projects.length);

  // Chart data for project progress
  const progressData = projects.map(project => ({
    name: project.name.length > 20 ? project.name.substring(0, 20) + '...' : project.name,
    progress: project.progress,
    budget: project.budget / 1000000, // Convert to millions
    expenses: project.expenses / 1000000,
  }));

  // Monthly timeline data (mock)
  const timelineData = [
    { month: 'يناير', planned: 20, actual: 18 },
    { month: 'فبراير', planned: 35, actual: 32 },
    { month: 'مارس', planned: 45, actual: 48 },
    { month: 'أبريل', planned: 60, actual: 55 },
    { month: 'مايو', planned: 75, actual: 70 },
    { month: 'يونيو', planned: 85, actual: 82 },
    { month: 'يوليو', planned: 90, actual: 88 },
    { month: 'أغسطس', planned: 95, actual: 92 },
  ];

  const handleViewProject = (project: Project) => {
    setSelectedProject(project);
  };

  const handleShowGantt = (project: Project) => {
    setSelectedProject(project);
    setShowGanttChart(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'نشط': return 'bg-emerald-100 text-emerald-800';
      case 'مكتمل': return 'bg-blue-100 text-blue-800';
      case 'متوقف': return 'bg-amber-100 text-amber-800';
      case 'ملغى': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">إدارة المشاريع</h1>
          <p className="text-gray-600 mt-1">إدارة المشاريع والجداول الزمنية</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3 space-x-reverse">
          <button 
            onClick={() => setShowAddForm(true)}
            className="btn-primary flex items-center"
          >
            <Plus className="h-4 w-4 ml-2" />
            مشروع جديد
          </button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">المشاريع النشطة</p>
              <p className="text-3xl font-bold text-emerald-600">{activeProjects}</p>
            </div>
            <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center">
              <Play className="h-6 w-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">المشاريع المكتملة</p>
              <p className="text-3xl font-bold text-blue-600">{completedProjects}</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">إجمالي الميزانيات</p>
              <p className="text-3xl font-bold text-gray-900">{(totalBudget / 1000000).toFixed(1)}م</p>
              <p className="text-xs text-gray-500">ج.م</p>
            </div>
            <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-amber-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">متوسط التقدم</p>
              <p className="text-3xl font-bold text-primary-600">{avgProgress}%</p>
            </div>
            <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center">
              <BarChart3 className="h-6 w-6 text-primary-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Project Progress Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">تقدم المشاريع</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={12} />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'progress' ? `${value}%` : `${value} مليون ج.م`,
                    name === 'progress' ? 'نسبة الإنجاز' : name === 'budget' ? 'الميزانية' : 'المصروف'
                  ]}
                />
                <Bar dataKey="progress" fill="#0ea5e9" name="نسبة الإنجاز %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Timeline Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">الجدول الزمني المخطط مقابل الفعلي</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value}%`, '']} />
                <Line type="monotone" dataKey="planned" stroke="#10b981" strokeWidth={2} name="مخطط" />
                <Line type="monotone" dataKey="actual" stroke="#f59e0b" strokeWidth={2} name="فعلي" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Projects Table */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">قائمة المشاريع</h3>
          <div className="text-sm text-gray-600">
            إجمالي: {projects.length} مشروع
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  اسم المشروع
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الموقع
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الميزانية (ج.م)
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المصروف (ج.م)
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  التقدم
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الإجراءات
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {projects.map((project) => (
                <tr key={project.id} className="table-row">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{project.name}</div>
                      <div className="text-sm text-gray-500">مدير: {project.projectManager}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{project.location}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{(project.budget / 1000000).toFixed(1)}م</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{(project.expenses / 1000000).toFixed(1)}م</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 ml-2">
                        <div 
                          className="bg-primary-600 h-2 rounded-full" 
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-900">{project.progress}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(project.status)}`}>
                      {project.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2 space-x-reverse">
                      <button 
                        onClick={() => handleViewProject(project)}
                        className="text-blue-600 hover:text-blue-900"
                        title="عرض التفاصيل"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button 
                        onClick={() => handleShowGantt(project)}
                        className="text-emerald-600 hover:text-emerald-900"
                        title="مخطط جانت"
                      >
                        <BarChart3 className="h-4 w-4" />
                      </button>
                      <button 
                        className="text-amber-600 hover:text-amber-900"
                        title="تعديل"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Project Details Modal */}
      {selectedProject && !showGanttChart && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">تفاصيل المشروع: {selectedProject.name}</h2>
              <button 
                onClick={() => setSelectedProject(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Project Info */}
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">معلومات المشروع</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">الموقع:</span>
                      <span className="text-sm font-medium">{selectedProject.location}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">تاريخ البدء:</span>
                      <span className="text-sm font-medium">
                        {new Date(selectedProject.startDate).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">تاريخ الانتهاء:</span>
                      <span className="text-sm font-medium">
                        {new Date(selectedProject.endDate).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">مدير المشروع:</span>
                      <span className="text-sm font-medium">{selectedProject.projectManager}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">الميزانية والمصروفات</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">الميزانية المعتمدة:</span>
                      <span className="text-sm font-medium">{selectedProject.budget.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">إجمالي المصروف:</span>
                      <span className="text-sm font-medium">{selectedProject.expenses.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">المتبقي:</span>
                      <span className="text-sm font-medium text-emerald-600">
                        {(selectedProject.budget - selectedProject.expenses).toLocaleString()} ج.م
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">نسبة الاستهلاك:</span>
                      <span className="text-sm font-medium">
                        {Math.round((selectedProject.expenses / selectedProject.budget) * 100)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Project Tasks */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900">مهام المشروع</h4>
                  <button 
                    onClick={() => handleShowGantt(selectedProject)}
                    className="btn-primary text-sm"
                  >
                    <BarChart3 className="h-4 w-4 ml-1" />
                    مخطط جانت
                  </button>
                </div>
                
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {selectedProject.tasks.map((task) => (
                    <div key={task.id} className="border border-gray-200 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="text-sm font-medium text-gray-900">{task.name}</h5>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          task.status === 'مكتمل' ? 'bg-emerald-100 text-emerald-800' :
                          task.status === 'قيد التنفيذ' ? 'bg-blue-100 text-blue-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {task.status}
                        </span>
                      </div>
                      
                      <div className="text-xs text-gray-600 mb-2">
                        {new Date(task.startDate).toLocaleDateString('ar-EG')} - {new Date(task.endDate).toLocaleDateString('ar-EG')}
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex-1 bg-gray-200 rounded-full h-2 ml-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${task.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-600">{task.progress}%</span>
                      </div>
                      
                      {task.assignedEmployees.length > 0 && (
                        <div className="text-xs text-gray-500 mt-2">
                          المعينون: {task.assignedEmployees.join(', ')}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3 space-x-reverse pt-6">
              <button 
                onClick={() => setSelectedProject(null)}
                className="btn-secondary"
              >
                إغلاق
              </button>
              <button className="btn-primary">
                تعديل المشروع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Gantt Chart Modal */}
      {selectedProject && showGanttChart && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-6xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">
                مخطط جانت - {selectedProject.name}
              </h2>
              <button 
                onClick={() => {
                  setShowGanttChart(false);
                  setSelectedProject(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>

            {/* Gantt Chart Simulation */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="text-center text-gray-600 mb-4">
                <BarChart3 className="h-16 w-16 mx-auto mb-2 text-gray-400" />
                <h3 className="text-lg font-medium">مخطط جانت التفاعلي</h3>
                <p className="text-sm">عرض مرئي للمهام والجدول الزمني للمشروع</p>
              </div>

              {/* Timeline Header */}
              <div className="border-b border-gray-200 pb-2 mb-4">
                <div className="grid grid-cols-12 gap-2 text-xs text-gray-600 text-center">
                  {['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 
                    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'].map(month => (
                    <div key={month}>{month}</div>
                  ))}
                </div>
              </div>

              {/* Tasks Timeline */}
              <div className="space-y-3">
                {selectedProject.tasks.map((task, index) => (
                  <div key={task.id} className="flex items-center">
                    <div className="w-48 text-sm text-gray-900 pr-4">
                      {task.name}
                    </div>
                    <div className="flex-1 grid grid-cols-12 gap-2 h-8">
                      {Array.from({ length: 12 }, (_, monthIndex) => {
                        const isActive = monthIndex >= index && monthIndex <= index + 2;
                        const progress = isActive ? task.progress : 0;
                        return (
                          <div key={monthIndex} className="relative">
                            <div className="h-6 bg-gray-200 rounded">
                              {isActive && (
                                <div 
                                  className="h-full bg-blue-500 rounded transition-all duration-300"
                                  style={{ width: `${progress}%` }}
                                ></div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="w-16 text-sm text-gray-600 text-center">
                      {task.progress}%
                    </div>
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="mt-6 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-center space-x-6 space-x-reverse text-sm">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-4 h-4 bg-blue-500 rounded"></div>
                    <span>مهام نشطة</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-4 h-4 bg-gray-200 rounded"></div>
                    <span>مهام غير نشطة</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-4 h-4 bg-emerald-500 rounded"></div>
                    <span>مهام مكتملة</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3 space-x-reverse pt-6">
              <button 
                onClick={() => {
                  setShowGanttChart(false);
                  setSelectedProject(null);
                }}
                className="btn-secondary"
              >
                إغلاق
              </button>
              <button className="btn-primary">
                تصدير PDF
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Project Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">إضافة مشروع جديد</h2>
              <button 
                onClick={() => setShowAddForm(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>

            <form className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    اسم المشروع *
                  </label>
                  <input type="text" className="input-field" placeholder="مشروع العاصمة الإدارية الجديدة" />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    وصف المشروع
                  </label>
                  <textarea className="input-field" rows={3} placeholder="وصف مفصل للمشروع..."></textarea>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    موقع المشروع *
                  </label>
                  <input type="text" className="input-field" placeholder="العاصمة الإدارية الجديدة" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    مدير المشروع *
                  </label>
                  <select className="input-field">
                    <option value="">اختر مدير المشروع</option>
                    <option value="أحمد محمد علي">أحمد محمد علي</option>
                    <option value="د. سارة محمود">د. سارة محمود</option>
                    <option value="خالد إبراهيم">خالد إبراهيم</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    تاريخ البدء *
                  </label>
                  <input type="date" className="input-field" defaultValue="2025-09-01" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    تاريخ الانتهاء المتوقع *
                  </label>
                  <input type="date" className="input-field" defaultValue="2026-08-31" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الميزانية المعتمدة (ج.م) *
                  </label>
                  <input type="number" className="input-field" placeholder="50000000" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    حالة المشروع
                  </label>
                  <select className="input-field">
                    <option value="مخطط">مخطط</option>
                    <option value="نشط">نشط</option>
                    <option value="متوقف">متوقف</option>
                    <option value="مكتمل">مكتمل</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-3 space-x-reverse pt-6">
                <button 
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="btn-secondary"
                >
                  إلغاء
                </button>
                <button 
                  type="submit"
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('تم إضافة المشروع بنجاح! يمكنك الآن إضافة المهام وإنشاء الجدول الزمني.');
                    setShowAddForm(false);
                  }}
                >
                  إنشاء المشروع
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Projects;

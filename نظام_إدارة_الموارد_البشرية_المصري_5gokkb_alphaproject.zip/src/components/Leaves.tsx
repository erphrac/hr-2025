import React, { useState } from 'react';
import { 
  Plus, Filter, Eye, Download, Check, X,
  Calendar, User, FileText, Briefcase
} from 'lucide-react';
import { mockLeaveRequests, mockEmployees, legalCompliance } from '../data/mockData';
import { LeaveRequest } from '../types';

const Leaves: React.FC = () => {
  const [leaveRequests] = useState<LeaveRequest[]>(mockLeaveRequests);
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<LeaveRequest | null>(null);

  // Filters state
  const [filters, setFilters] = useState({
    employeeName: '',
    type: '',
    status: '',
  });

  // Filter logic
  const filteredRequests = leaveRequests.filter(req => {
    const matchesName = req.employeeName.toLowerCase().includes(filters.employeeName.toLowerCase());
    const matchesType = filters.type === '' || req.type === filters.type;
    const matchesStatus = filters.status === '' || req.status === filters.status;
    return matchesName && matchesType && matchesStatus;
  });

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  // Calculate statistics
  const totalRequests = leaveRequests.length;
  const pendingRequests = leaveRequests.filter(r => r.status === 'معلق').length;
  const approvedRequests = leaveRequests.filter(r => r.status === 'موافق عليه').length;
  
  // Mock current user's leave balance
  const currentUserLeaveBalance = {
    annual: 15, // اعتيادي
    casual: 5, // عارضة
    sick: 90, // مرضي
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'موافق عليه': return 'bg-emerald-100 text-emerald-800';
      case 'مرفوض': return 'bg-red-100 text-red-800';
      case 'معلق': return 'bg-amber-100 text-amber-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">إدارة الإجازات</h1>
          <p className="text-gray-600 mt-1">إدارة طلبات الإجازات وأرصدة الموظفين وفق القانون الجديد</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3 space-x-reverse">
          <button 
            onClick={() => setShowAddForm(true)}
            className="btn-primary flex items-center"
          >
            <Plus className="h-4 w-4 ml-2" />
            طلب إجازة جديد
          </button>
          <button className="btn-secondary flex items-center">
            <Download className="h-4 w-4 ml-2" />
            تصدير التقرير
          </button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">إجمالي الطلبات</p>
          <p className="text-2xl font-bold text-gray-900">{totalRequests}</p>
        </div>
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">طلبات معلقة</p>
          <p className="text-2xl font-bold text-amber-600">{pendingRequests}</p>
        </div>
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">طلبات موافق عليها</p>
          <p className="text-2xl font-bold text-emerald-600">{approvedRequests}</p>
        </div>
        <div className="stat-card bg-primary-50 border-primary-200">
          <p className="text-sm font-medium text-primary-700">رصيد إجازاتي الاعتيادي</p>
          <p className="text-2xl font-bold text-primary-800">{currentUserLeaveBalance.annual} يوم</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <input
            type="text"
            name="employeeName"
            placeholder="بحث باسم الموظف..."
            value={filters.employeeName}
            onChange={handleFilterChange}
            className="input-field"
          />
          <select name="type" value={filters.type} onChange={handleFilterChange} className="input-field">
            <option value="">كل أنواع الإجازات</option>
            <option value="اعتيادية">اعتيادية</option>
            <option value="مرضية">مرضية</option>
            <option value="أمومة">أمومة</option>
            <option value="حج">حج</option>
            <option value="طوارئ">طوارئ</option>
          </select>
          <select name="status" value={filters.status} onChange={handleFilterChange} className="input-field">
            <option value="">كل الحالات</option>
            <option value="معلق">معلق</option>
            <option value="موافق عليه">موافق عليه</option>
            <option value="مرفوض">مرفوض</option>
          </select>
          <button className="btn-secondary flex items-center justify-center">
            <Filter className="h-4 w-4 ml-2" />
            تطبيق الفلتر
          </button>
        </div>
      </div>

      {/* Leave Requests Table */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">سجل طلبات الإجازات</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الموظف</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">نوع الإجازة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المدة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">تاريخ البدء</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">تاريخ الانتهاء</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الحالة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRequests.map((request) => (
                <tr key={request.id} className="table-row">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{request.employeeName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{request.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{request.days} أيام</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{new Date(request.startDate).toLocaleDateString('ar-EG')}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{new Date(request.endDate).toLocaleDateString('ar-EG')}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(request.status)}`}>
                      {request.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2 space-x-reverse">
                      {request.status === 'معلق' && (
                        <>
                          <button className="text-emerald-600 hover:text-emerald-900" title="موافقة"><Check className="h-4 w-4" /></button>
                          <button className="text-red-600 hover:text-red-900" title="رفض"><X className="h-4 w-4" /></button>
                        </>
                      )}
                      <button onClick={() => setSelectedRequest(request)} className="text-blue-600 hover:text-blue-900" title="عرض التفاصيل"><Eye className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Leave Request Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">تقديم طلب إجازة جديد</h2>
              <button onClick={() => setShowAddForm(false)} className="text-gray-500 hover:text-gray-700">×</button>
            </div>
            <form className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">الموظف *</label>
                  <select className="input-field">
                    <option value="">اختر الموظف</option>
                    {mockEmployees.map(emp => <option key={emp.id} value={emp.id}>{emp.fullName}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نوع الإجازة *</label>
                  <select className="input-field">
                    <option value="اعتيادية">اعتيادية (رصيد: {legalCompliance.annualLeaveDays} يوم)</option>
                    <option value="مرضية">مرضية (رصيد: 90 يوم)</option>
                    <option value="أمومة">أمومة (رصيد: {legalCompliance.materniteLeaveDays} يوم)</option>
                    <option value="حج">حج (رصيد: {legalCompliance.hajjLeaveDays} أيام)</option>
                    <option value="طوارئ">طوارئ</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">تاريخ البدء *</label>
                  <input type="date" className="input-field" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">تاريخ الانتهاء *</label>
                  <input type="date" className="input-field" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">السبب</label>
                  <textarea className="input-field" rows={3} placeholder="يرجى توضيح سبب الإجازة..."></textarea>
                </div>
                <div className="md:col-span-2">
                   <label className="block text-sm font-medium text-gray-700 mb-2">إرفاق مستند (اختياري)</label>
                   <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                    <div className="space-y-1 text-center">
                      <FileText className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none">
                          <span>ارفع ملف</span>
                          <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                        </label>
                        <p className="pl-1">أو اسحبه وأفلته هنا</p>
                      </div>
                      <p className="text-xs text-gray-500">PDF, PNG, JPG حتى 10 ميجا</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-3 space-x-reverse pt-4">
                <button type="button" onClick={() => setShowAddForm(false)} className="btn-secondary">إلغاء</button>
                <button type="submit" className="btn-primary" onClick={(e) => { e.preventDefault(); setShowAddForm(false); }}>إرسال الطلب</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Leave Request Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">تفاصيل طلب الإجازة</h2>
              <button onClick={() => setSelectedRequest(null)} className="text-gray-500 hover:text-gray-700">×</button>
            </div>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 space-x-reverse">
                <User className="h-5 w-5 text-gray-400" />
                <p><span className="font-medium">الموظف:</span> {selectedRequest.employeeName}</p>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Briefcase className="h-5 w-5 text-gray-400" />
                <p><span className="font-medium">نوع الإجازة:</span> {selectedRequest.type}</p>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Calendar className="h-5 w-5 text-gray-400" />
                <p><span className="font-medium">المدة:</span> {new Date(selectedRequest.startDate).toLocaleDateString('ar-EG')} إلى {new Date(selectedRequest.endDate).toLocaleDateString('ar-EG')} ({selectedRequest.days} أيام)</p>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse">
                <FileText className="h-5 w-5 text-gray-400" />
                <p><span className="font-medium">السبب:</span> {selectedRequest.reason}</p>
              </div>
              <div>
                <span className="font-medium">الحالة:</span>
                <span className={`ml-2 px-2 py-1 text-sm font-medium rounded-full ${getStatusColor(selectedRequest.status)}`}>
                  {selectedRequest.status}
                </span>
              </div>
              <div className="flex justify-end pt-4">
                <button onClick={() => setSelectedRequest(null)} className="btn-secondary">إغلاق</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Leaves;

import React, { useState } from 'react';
import { mockPayroll, mockEmployees, mockDepartments } from '../data/mockData';
import { Payroll as PayrollType, Employee } from '../types';
import { 
  DollarSign, Eye, Printer, Plus, FileText, ChevronDown, Download
} from 'lucide-react';
import { exportPayrollToCsv, exportPayrollToPdf } from '../utils/export';
import { Dropdown, DropdownTrigger, DropdownContent, DropdownItem } from './ui/Dropdown';

const Payroll: React.FC = () => {
  const [payrolls] = useState<PayrollType[]>(mockPayroll);
  const [selectedMonth, setSelectedMonth] = useState('08');
  const [selectedYear, setSelectedYear] = useState('2025');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedPayslip, setSelectedPayslip] = useState<{ payroll: PayrollType, employee: Employee | undefined } | null>(null);

  // Filtering logic
  const filteredPayrolls = payrolls.filter(p => {
    const employee = mockEmployees.find(e => e.id === p.employeeId);
    const payrollMonthYear = `${selectedYear}-${selectedMonth}`;
    const matchesMonth = p.month === payrollMonthYear;
    const matchesDept = selectedDepartment === '' || employee?.department === selectedDepartment;
    return matchesMonth && matchesDept;
  });

  // Stats calculation based on filtered data
  const totalNetSalary = filteredPayrolls.reduce((sum, p) => sum + p.netSalary, 0);
  const totalDeductions = filteredPayrolls.reduce((sum, p) => sum + p.socialInsurance + p.taxes + p.penalties, 0);
  const totalOvertime = filteredPayrolls.reduce((sum, p) => sum + p.overtimePay, 0);
  const avgSalary = filteredPayrolls.length > 0 ? Math.round(totalNetSalary / filteredPayrolls.length) : 0;

  // Handlers
  const handleCalculatePayroll = () => {
    alert(`سيتم الآن حساب رواتب شهر ${new Date(parseInt(selectedYear), parseInt(selectedMonth) - 1).toLocaleString('ar-EG', { month: 'long' })} ${selectedYear} لجميع الموظفين...`);
    // In a real app, this would trigger a backend process.
  };

  const handleViewPayslip = (payroll: PayrollType) => {
    const employee = mockEmployees.find(e => e.id === payroll.employeeId);
    setSelectedPayslip({ payroll, employee });
  };

  const handlePrintPayslip = () => {
    window.print();
  };

  const handleExportCsv = () => {
    const monthName = new Date(parseInt(selectedYear), parseInt(selectedMonth) - 1).toLocaleString('ar-EG', { month: 'long' });
    const filename = `payroll-report-${monthName}-${selectedYear}.csv`;
    exportPayrollToCsv(filename, filteredPayrolls);
  };

  const handleExportPdf = () => {
    const monthName = new Date(parseInt(selectedYear), parseInt(selectedMonth) - 1).toLocaleString('ar-EG', { month: 'long' });
    const filename = `payroll-report-${monthName}-${selectedYear}.pdf`;
    const reportTitle = `تقرير رواتب شهر ${monthName} ${selectedYear}`;
    exportPayrollToPdf(filename, filteredPayrolls, reportTitle);
  };


  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">المرتبات</h1>
          <p className="text-gray-600 mt-1">إدارة وحساب رواتب الموظفين الشهرية</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3 space-x-reverse">
          <button 
            onClick={handleCalculatePayroll}
            className="btn-primary flex items-center"
          >
            <Plus className="h-4 w-4 ml-2" />
            حساب رواتب الشهر
          </button>
          
          <Dropdown>
            <DropdownTrigger>
              <button className="btn-secondary flex items-center">
                تصدير التقرير
                <ChevronDown className="h-4 w-4 mr-2" />
              </button>
            </DropdownTrigger>
            <DropdownContent>
              <DropdownItem onClick={handleExportCsv}>
                <div className="flex items-center">
                  <Download className="h-4 w-4 ml-2 text-gray-500" />
                  <span>تصدير Excel (CSV)</span>
                </div>
              </DropdownItem>
              <DropdownItem onClick={handleExportPdf}>
                <div className="flex items-center">
                  <FileText className="h-4 w-4 ml-2 text-gray-500" />
                  <span>تصدير PDF</span>
                </div>
              </DropdownItem>
            </DropdownContent>
          </Dropdown>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">إجمالي الرواتب (الصافي)</p>
          <p className="text-2xl font-bold text-gray-900">{(totalNetSalary / 1000).toFixed(1)} ألف</p>
          <p className="text-xs text-gray-500">ج.م</p>
        </div>
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">متوسط الراتب</p>
          <p className="text-2xl font-bold text-gray-900">{avgSalary.toLocaleString()} </p>
          <p className="text-xs text-gray-500">ج.م</p>
        </div>
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">إجمالي الاستقطاعات</p>
          <p className="text-2xl font-bold text-red-600">{totalDeductions.toLocaleString()}</p>
          <p className="text-xs text-gray-500">تأمينات، ضرائب، غرامات</p>
        </div>
        <div className="stat-card">
          <p className="text-sm font-medium text-gray-600">إجمالي الساعات الإضافية</p>
          <p className="text-2xl font-bold text-emerald-600">{totalOvertime.toLocaleString()}</p>
          <p className="text-xs text-gray-500">ج.م (أجر إضافي 35%)</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select 
            value={selectedMonth} 
            onChange={(e) => setSelectedMonth(e.target.value)} 
            className="input-field"
          >
            {Array.from({ length: 12 }, (_, i) => (
              <option key={i} value={(i + 1).toString().padStart(2, '0')}>
                {new Date(0, i).toLocaleString('ar-EG', { month: 'long' })}
              </option>
            ))}
          </select>
          <select 
            value={selectedYear} 
            onChange={(e) => setSelectedYear(e.target.value)} 
            className="input-field"
          >
            <option value="2025">2025</option>
            <option value="2024">2024</option>
          </select>
          <select 
            value={selectedDepartment} 
            onChange={(e) => setSelectedDepartment(e.target.value)} 
            className="input-field"
          >
            <option value="">جميع الأقسام</option>
            {mockDepartments.map(dept => (
              <option key={dept.id} value={dept.name}>{dept.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Payroll Table */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          كشف رواتب شهر {new Date(parseInt(selectedYear), parseInt(selectedMonth) - 1).toLocaleString('ar-EG', { month: 'long', year: 'numeric' })}
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الموظف</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الراتب الأساسي</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الإضافي</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الاستقطاعات</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">صافي الراتب</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الحالة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredPayrolls.map((payroll) => (
                <tr key={payroll.id} className="table-row">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{payroll.employeeName}</div>
                    <div className="text-sm text-gray-500">{mockEmployees.find(e => e.id === payroll.employeeId)?.department}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{payroll.basicSalary.toLocaleString()} ج.م</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-emerald-600">{payroll.overtimePay.toLocaleString()} ج.م</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">{(payroll.socialInsurance + payroll.taxes + payroll.penalties).toLocaleString()} ج.م</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{payroll.netSalary.toLocaleString()} ج.م</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-emerald-100 text-emerald-800">
                      مدفوع
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onClick={() => handleViewPayslip(payroll)} className="text-blue-600 hover:text-blue-900 flex items-center">
                      <Eye className="h-4 w-4 ml-1" />
                      عرض
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payslip Modal */}
      {selectedPayslip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 print:bg-white print:p-0">
          <div id="payslip-modal" className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">كشف راتب شهر {new Date(selectedPayslip.payroll.month).toLocaleString('ar-EG', { month: 'long', year: 'numeric' })}</h2>
                <button onClick={() => setSelectedPayslip(null)} className="text-gray-500 hover:text-gray-700 print:hidden">×</button>
              </div>

              <div className="border rounded-lg p-4 mb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">اسم الموظف</p>
                    <p className="font-medium text-gray-900">{selectedPayslip.employee?.fullName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">الرقم القومي</p>
                    <p className="font-medium text-gray-900">{selectedPayslip.employee?.nationalId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">القسم</p>
                    <p className="font-medium text-gray-900">{selectedPayslip.employee?.department}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">الوظيفة</p>
                    <p className="font-medium text-gray-900">{selectedPayslip.employee?.jobTitle}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                {/* Earnings */}
                <div>
                  <h3 className="text-lg font-semibold text-emerald-700 mb-2 border-b pb-1">الدخل</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">الراتب الأساسي</span>
                      <span>{selectedPayslip.payroll.basicSalary.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">بدل ساعات إضافية</span>
                      <span>{selectedPayslip.payroll.overtimePay.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between font-bold text-gray-900 border-t pt-2 mt-2">
                      <span>إجمالي الدخل</span>
                      <span>{(selectedPayslip.payroll.basicSalary + selectedPayslip.payroll.overtimePay).toLocaleString()} ج.م</span>
                    </div>
                  </div>
                </div>
                {/* Deductions */}
                <div>
                  <h3 className="text-lg font-semibold text-red-700 mb-2 border-b pb-1">الاستقطاعات</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">التأمين الاجتماعي (14%)</span>
                      <span>{selectedPayslip.payroll.socialInsurance.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">ضرائب</span>
                      <span>{selectedPayslip.payroll.taxes.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">غرامات</span>
                      <span>{selectedPayslip.payroll.penalties.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between font-bold text-gray-900 border-t pt-2 mt-2">
                      <span>إجمالي الاستقطاعات</span>
                      <span>{(selectedPayslip.payroll.socialInsurance + selectedPayslip.payroll.taxes + selectedPayslip.payroll.penalties).toLocaleString()} ج.م</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-primary-50 border-t-4 border-primary-500 rounded-b-lg p-4 mt-6 text-center">
                <p className="text-lg font-bold text-primary-800">صافي الراتب المستحق</p>
                <p className="text-3xl font-extrabold text-primary-900 my-2">{selectedPayslip.payroll.netSalary.toLocaleString()} ج.م</p>
              </div>

              <div className="text-xs text-gray-500 text-center mt-4 print:block hidden">
                * تم الحساب وفقاً لقانون العمل المصري رقم 14 لسنة 2025
              </div>
            </div>

            <div className="p-4 bg-gray-50 border-t flex justify-end space-x-3 space-x-reverse print:hidden">
              <button onClick={() => setSelectedPayslip(null)} className="btn-secondary">إغلاق</button>
              <button onClick={handlePrintPayslip} className="btn-primary flex items-center">
                <Printer className="h-4 w-4 ml-2" />
                طباعة
              </button>
            </div>
          </div>
          <style>{`
            @media print {
              body * {
                visibility: hidden;
              }
              #payslip-modal, #payslip-modal * {
                visibility: visible;
              }
              .print\\:hidden {
                display: none;
              }
              #payslip-modal {
                position: absolute;
                right: 0;
                top: 0;
                width: 100%;
                height: auto;
                box-shadow: none;
                border: none;
                max-height: none;
                overflow: visible;
              }
            }
          `}</style>
        </div>
      )}
    </div>
  );
};

export default Payroll;

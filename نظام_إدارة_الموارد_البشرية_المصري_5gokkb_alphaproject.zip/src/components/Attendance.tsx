import React, { useState, useEffect } from 'react';
import { 
  Clock, MapPin, Users, TrendingUp, Calendar,
  CheckCircle, XCircle, AlertTriangle, Plus, Download
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { mockAttendance, mockEmployees } from '../data/mockData';
import { Attendance as AttendanceType } from '../types';

const Attendance: React.FC = () => {
  const [attendance] = useState<AttendanceType[]>(mockAttendance);
  const [selectedDate, setSelectedDate] = useState('2025-08-23');
  const [showCheckInForm, setShowCheckInForm] = useState(false);
  const [checkInTime, setCheckInTime] = useState('');

  useEffect(() => {
    let timer: number;
    if (showCheckInForm) {
      const updateTime = () => {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        setCheckInTime(`${hours}:${minutes}`);
      };
      updateTime(); // Set time immediately
      timer = setInterval(updateTime, 1000); // Update every second
    }
    return () => clearInterval(timer); // Cleanup on unmount or when modal closes
  }, [showCheckInForm]);

  // Filter attendance by selected date
  const dayAttendance = attendance.filter(att => att.date === selectedDate);
  
  // Calculate statistics
  const totalEmployees = mockEmployees.length;
  const presentCount = dayAttendance.filter(att => att.status === 'حاضر' || att.status === 'متأخر').length;
  const absentCount = dayAttendance.filter(att => att.status === 'غائب').length;
  const lateCount = dayAttendance.filter(att => att.status === 'متأخر').length;
  const attendanceRate = totalEmployees > 0 ? Math.round((presentCount / totalEmployees) * 100) : 0;
  
  const totalOvertimeHours = dayAttendance.reduce((sum, att) => sum + att.overtimeHours, 0);
  const avgWorkingHours = dayAttendance.length > 0 
    ? (dayAttendance.reduce((sum, att) => sum + att.workingHours, 0) / dayAttendance.length).toFixed(1)
    : '0';

  // Chart data for attendance status
  const attendanceChartData = [
    { name: 'حاضر', value: presentCount - lateCount, color: '#10b981' },
    { name: 'متأخر', value: lateCount, color: '#f59e0b' },
    { name: 'غائب', value: absentCount, color: '#ef4444' },
  ];

  // Department attendance data
  const departmentAttendance = mockEmployees.reduce((acc: any[], emp) => {
    const existing = acc.find(item => item.department === emp.department);
    const empAttendance = dayAttendance.find(att => att.employeeId === emp.id);
    const isPresent = empAttendance && (empAttendance.status === 'حاضر' || empAttendance.status === 'متأخر');
    
    if (existing) {
      existing.total += 1;
      if (isPresent) existing.present += 1;
    } else {
      acc.push({
        department: emp.department,
        total: 1,
        present: isPresent ? 1 : 0,
      });
    }
    return acc;
  }, []).map(item => ({
    ...item,
    rate: item.total > 0 ? Math.round((item.present / item.total) * 100) : 0
  }));

  const handleQuickCheckIn = () => {
    setShowCheckInForm(true);
  };

  const handleExportAttendance = () => {
    alert('سيتم تصدير بيانات الحضور إلى ملف Excel');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">الحضور والغياب</h1>
          <p className="text-gray-600 mt-1">إدارة حضور الموظفين والتوقيتات</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3 space-x-reverse">
          <button 
            onClick={handleQuickCheckIn}
            className="btn-primary flex items-center"
          >
            <Plus className="h-4 w-4 ml-2" />
            تسجيل حضور
          </button>
          <button 
            onClick={handleExportAttendance}
            className="btn-secondary flex items-center"
          >
            <Download className="h-4 w-4 ml-2" />
            تصدير التقرير
          </button>
        </div>
      </div>

      {/* Date Selector */}
      <div className="card">
        <div className="flex items-center space-x-4 space-x-reverse">
          <Calendar className="h-5 w-5 text-gray-400" />
          <label className="text-sm font-medium text-gray-700">تاريخ العرض:</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="input-field w-auto"
          />
          <div className="text-sm text-gray-600">
            {new Date(selectedDate).toLocaleDateString('ar-EG', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">معدل الحضور</p>
              <p className="text-3xl font-bold text-gray-900">{attendanceRate}%</p>
              <p className="text-sm text-emerald-600 mt-1">
                {presentCount} من {totalEmployees} موظف
              </p>
            </div>
            <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">الموظفين الحاضرين</p>
              <p className="text-3xl font-bold text-emerald-600">{presentCount}</p>
              <p className="text-sm text-gray-600 mt-1">متوسط {avgWorkingHours} ساعة</p>
            </div>
            <div className="h-12 w-12 bg-emerald-100 rounded-full flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">المتأخرين</p>
              <p className="text-3xl font-bold text-amber-600">{lateCount}</p>
              <p className="text-sm text-gray-600 mt-1">تطبيق غرامة 1/30</p>
            </div>
            <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
              <AlertTriangle className="h-6 w-6 text-amber-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">الساعات الإضافية</p>
              <p className="text-3xl font-bold text-blue-600">{totalOvertimeHours.toFixed(1)}</p>
              <p className="text-sm text-gray-600 mt-1">أجر إضافي 35%</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Clock className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Attendance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Attendance Status Pie Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">توزيع حالات الحضور</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceChartData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {attendanceChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Department Attendance Bar Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">معدل الحضور بالأقسام</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentAttendance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="department" fontSize={12} />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'rate' ? `${value}%` : value,
                    name === 'rate' ? 'معدل الحضور' : name
                  ]}
                />
                <Bar dataKey="rate" fill="#0ea5e9" name="معدل الحضور %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Attendance Table */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">سجل الحضور اليومي</h3>
          <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-600">
            <span>إجمالي: {dayAttendance.length} سجل</span>
            <span>معدل الحضور: {attendanceRate}%</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الموظف
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  وقت الدخول
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  وقت الخروج
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ساعات العمل
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ساعات إضافية
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الموقع
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {dayAttendance.map((record) => (
                <tr key={record.id} className="table-row">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-8 w-8 bg-primary-100 rounded-full flex items-center justify-center ml-3">
                        <Users className="h-4 w-4 text-primary-600" />
                      </div>
                      <div className="text-sm font-medium text-gray-900">
                        {record.employeeName}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {record.checkIn || '--'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {record.checkOut || '--'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {record.workingHours} ساعة
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {record.overtimeHours > 0 ? `${record.overtimeHours} ساعة` : '--'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      record.status === 'حاضر' ? 'bg-emerald-100 text-emerald-800' :
                      record.status === 'متأخر' ? 'bg-amber-100 text-amber-800' :
                      record.status === 'غائب' ? 'bg-red-100 text-red-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {record.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <MapPin className="h-4 w-4 text-gray-400 ml-1" />
                      {record.location || 'المكتب الرئيسي'}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Check-in Modal */}
      {showCheckInForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">تسجيل حضور سريع</h2>
              <button 
                onClick={() => setShowCheckInForm(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الموظف *
                </label>
                <select className="input-field">
                  <option value="">اختر الموظف</option>
                  {mockEmployees.filter(emp => emp.isActive).map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.fullName}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الموقع
                </label>
                <div className="flex items-center space-x-2 space-x-reverse bg-gray-100 p-2 rounded-md">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <p className="text-sm text-gray-700">سيتم تحديد الموقع تلقائياً عبر GPS</p>
                </div>
                <p className="text-xs text-gray-500 mt-1">الموقع الحالي: المكتب الرئيسي، القاهرة</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  الوقت
                </label>
                <input 
                  type="text" 
                  className="input-field bg-gray-100" 
                  value={checkInTime}
                  readOnly
                />
              </div>

              <div className="bg-blue-50 p-3 rounded-lg border-r-4 border-blue-400">
                <h4 className="text-sm font-medium text-blue-900 mb-1">معلومات قانونية</h4>
                <ul className="text-xs text-blue-700 space-y-1 list-disc pr-4">
                  <li>ساعات العمل القانونية: 8 ساعات يومياً (قانون 14/2025)</li>
                  <li>الساعات الإضافية: أجر إضافي 35%</li>
                  <li>التأخير: غرامة 1/30 من الراتب</li>
                </ul>
              </div>

              <div className="flex justify-end space-x-3 space-x-reverse pt-4">
                <button 
                  type="button"
                  onClick={() => setShowCheckInForm(false)}
                  className="btn-secondary"
                >
                  إلغاء
                </button>
                <button 
                  type="submit"
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('تم تسجيل الحضور بنجاح! سيتم إرسال إشعار SMS للموظف.');
                    setShowCheckInForm(false);
                  }}
                >
                  تسجيل الحضور
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Attendance;

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Users, Clock, DollarSign, Calendar, FileText, 
  Building2, Settings, BarChart3, Bell, Search, 
  Menu, X, LogOut, User 
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
}

const Sidebar: React.FC<{ currentPage: string; onPageChange: (page: string) => void; onLinkClick: () => void; }> = ({ currentPage, onPageChange, onLinkClick }) => {
  const menuItems = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
    { id: 'employees', label: 'إدارة الموظفين', icon: Users },
    { id: 'attendance', label: 'الحضور والغياب', icon: Clock },
    { id: 'payroll', label: 'المرتبات', icon: DollarSign },
    { id: 'leaves', label: 'الإجازات', icon: Calendar },
    { id: 'projects', label: 'إدارة المشاريع', icon: BarChart3 },
    { id: 'reports', label: 'التقارير', icon: FileText },
    { id: 'departments', label: 'الأقسام', icon: Building2 },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <aside className="w-64 flex-shrink-0 bg-white border-l border-gray-200 flex flex-col">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 flex-shrink-0">
        <h1 className="text-xl font-bold text-primary-700">نظام HR</h1>
        <button 
          onClick={onLinkClick}
          className="lg:hidden p-1 rounded-md hover:bg-gray-100"
        >
          <X className="h-6 w-6 text-gray-600" />
        </button>
      </div>
      
      <div className="p-4 border-b border-gray-200 bg-primary-50 flex-shrink-0 text-center">
        <div className="text-sm text-primary-800 font-semibold">شركة المقاولات المصرية</div>
        <div className="text-xs text-primary-600 mt-1">متوافق مع قانون العمل 14/2025</div>
      </div>

      <nav className="mt-4 px-4 space-y-1 flex-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                onPageChange(item.id);
                onLinkClick();
              }}
              className={`sidebar-item w-full ${currentPage === item.id ? 'active' : ''}`}
            >
              <Icon className="h-5 w-5 ml-3" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-200 flex-shrink-0">
        <div className="bg-gray-100 rounded-lg p-3 text-center">
          <div className="text-xs text-gray-600">آخر تحديث</div>
          <div className="text-sm font-medium text-gray-800">23 أغسطس 2025</div>
        </div>
      </div>
    </aside>
  );
};

const Layout: React.FC<LayoutProps> = ({ children, currentPage, onPageChange }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifications] = useState(3); // Mock notification count
  
  const formattedDate = new Date().toLocaleDateString('ar-EG-u-nu-arab', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const pageTitles: { [key: string]: string } = {
    dashboard: 'لوحة التحكم الرئيسية',
    employees: 'إدارة الموظفين',
    attendance: 'الحضور والغياب',
    payroll: 'المرتبات',
    leaves: 'الإجازات',
    projects: 'إدارة المشاريع',
    reports: 'التقارير',
    departments: 'الأقسام',
    settings: 'الإعدادات',
  };

  return (
    <div className="flex h-screen bg-gray-50 font-cairo" dir="rtl">
      {/* Mobile Sidebar */}
      <div className={`fixed inset-0 flex z-40 lg:hidden transition-transform duration-300 ease-in-out ${sidebarOpen ? 'translate-x-0' : 'translate-x-full'}`} id="mobile-sidebar">
        <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
          <Sidebar currentPage={currentPage} onPageChange={onPageChange} onLinkClick={() => setSidebarOpen(false)} />
        </div>
        <div className="flex-shrink-0 w-14" aria-hidden="true" onClick={() => setSidebarOpen(false)}>
          {/* Overlay */}
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex lg:flex-shrink-0">
        <div className="flex flex-col w-64 fixed h-full">
          <Sidebar currentPage={currentPage} onPageChange={onPageChange} onLinkClick={() => {}} />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden lg:mr-64">
        {/* Header */}
        <header className="relative bg-white shadow-sm border-b border-gray-200 flex-shrink-0 z-30">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-md hover:bg-gray-100 ml-4"
              >
                <Menu className="h-6 w-6" />
              </button>
              
              <div>
                <h2 className="text-lg font-semibold text-gray-800">
                  {pageTitles[currentPage] || 'لوحة التحكم'}
                </h2>
                <div className="text-sm text-gray-600">
                  {formattedDate}
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2 space-x-reverse">
              {/* Search */}
              <div className="hidden md:flex items-center">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <input 
                    type="text" 
                    placeholder="بحث..."
                    className="input-field pr-10"
                  />
                </div>
              </div>

              {/* Notifications */}
              <button className="relative p-2 text-gray-600 hover:text-gray-800">
                <Bell className="h-6 w-6" />
                {notifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {notifications}
                  </span>
                )}
              </button>

              {/* User Menu */}
              <div className="flex items-center space-x-2 space-x-reverse">
                <button className="flex items-center space-x-2 space-x-reverse p-2 rounded-lg hover:bg-gray-100">
                  <div className="text-right hidden sm:block">
                    <div className="text-sm font-medium text-gray-800">أحمد محمد علي</div>
                    <div className="text-xs text-gray-600">مدير الموارد البشرية</div>
                  </div>
                  <div className="h-8 w-8 bg-primary-100 rounded-full flex items-center justify-center">
                    <User className="h-5 w-5 text-primary-600" />
                  </div>
                </button>
                
                <button className="p-2 text-gray-600 hover:text-gray-800">
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 relative overflow-y-auto p-4 sm:p-6 bg-gray-50 focus:outline-none">
          <div className="w-full mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;

import React, { useState } from 'react';
import { 
  Plus, Search, Filter, Edit, Trash2, Eye, 
  Download, Phone, Mail, Calendar,
  Building2, MapPin, User, FileText, ChevronDown, Users, DollarSign 
} from 'lucide-react';
import { mockEmployees, mockDepartments } from '../data/mockData';
import { Employee } from '../types';
import { exportEmployeesToCsv, exportEmployeesToPdf } from '../utils/export';
import { Dropdown, DropdownTrigger, DropdownContent, DropdownItem } from './ui/Dropdown';

const Employees: React.FC = () => {
  const [employees] = useState<Employee[]>(mockEmployees);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  // Filter employees based on search and department
  const filteredEmployees = employees.filter(emp => {
    const matchesSearch = emp.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.nationalId.includes(searchTerm) ||
                         emp.phone.includes(searchTerm);
    const matchesDepartment = selectedDepartment === '' || emp.department === selectedDepartment;
    return matchesSearch && matchesDepartment;
  });

  const handleAddEmployee = () => {
    setShowAddForm(true);
  };

  const handleViewEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
  };

  const handleExportCsv = () => {
    const filename = `employees-report-${new Date().toISOString().split('T')[0]}.csv`;
    exportEmployeesToCsv(filename, filteredEmployees);
  };

  const handleExportPdf = () => {
    const filename = `employees-report-${new Date().toISOString().split('T')[0]}.pdf`;
    exportEmployeesToPdf(filename, filteredEmployees);
  };

  // Calculate statistics
  const totalEmployees = employees.length;
  const activeEmployees = employees.filter(emp => emp.isActive).length;
  const avgSalary = employees.length > 0 ? Math.round(employees.reduce((sum, emp) => sum + emp.salary, 0) / employees.length) : 0;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">إدارة الموظفين</h1>
          <p className="text-gray-600 mt-1">إدارة بيانات الموظفين والمراجعات</p>
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3 space-x-reverse">
          <button 
            onClick={handleAddEmployee}
            className="btn-primary flex items-center"
          >
            <Plus className="h-4 w-4 ml-2" />
            إضافة موظف
          </button>
          
          <Dropdown>
            <DropdownTrigger>
              <button className="btn-secondary flex items-center">
                تصدير
                <ChevronDown className="h-4 w-4 mr-2" />
              </button>
            </DropdownTrigger>
            <DropdownContent>
              <DropdownItem onClick={handleExportCsv}>
                <div className="flex items-center">
                  <Download className="h-4 w-4 ml-2 text-gray-500" />
                  <span>تصدير Excel (CSV)</span>
                </div>
              </DropdownItem>
              <DropdownItem onClick={handleExportPdf}>
                <div className="flex items-center">
                  <FileText className="h-4 w-4 ml-2 text-gray-500" />
                  <span>تصدير PDF</span>
                </div>
              </DropdownItem>
            </DropdownContent>
          </Dropdown>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">إجمالي الموظفين</p>
              <p className="text-2xl font-bold text-gray-900">{totalEmployees}</p>
            </div>
            <div className="h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center">
              <Users className="h-5 w-5 text-primary-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">الموظفين النشطين</p>
              <p className="text-2xl font-bold text-gray-900">{activeEmployees}</p>
            </div>
            <div className="h-10 w-10 bg-emerald-100 rounded-full flex items-center justify-center">
              <User className="h-5 w-5 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">متوسط الراتب</p>
              <p className="text-2xl font-bold text-gray-900">{avgSalary.toLocaleString()}</p>
              <p className="text-xs text-gray-500">ج.م</p>
            </div>
            <div className="h-10 w-10 bg-amber-100 rounded-full flex items-center justify-center">
              <DollarSign className="h-5 w-5 text-amber-600" />
            </div>
          </div>
        </div>

        <div className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">عدد الأقسام</p>
              <p className="text-2xl font-bold text-gray-900">{mockDepartments.length}</p>
            </div>
            <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
              <Building2 className="h-5 w-5 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="card">
        <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4 md:space-x-reverse">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="بحث بالاسم، الرقم القومي، أو الهاتف..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pr-10"
              />
            </div>
          </div>
          
          <div className="md:w-64">
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="input-field"
            >
              <option value="">جميع الأقسام</option>
              {mockDepartments.map(dept => (
                <option key={dept.id} value={dept.name}>{dept.name}</option>
              ))}
            </select>
          </div>
          
          <button className="btn-secondary flex items-center">
            <Filter className="h-4 w-4 ml-2" />
            فلاتر متقدمة
          </button>
        </div>
      </div>

      {/* Employees Table */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">قائمة الموظفين</h3>
          <p className="text-sm text-gray-600">
            إجمالي: {filteredEmployees.length} موظف
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الموظف
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الوظيفة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الراتب (ج.م)
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الهاتف
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  تاريخ التوظيف
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الحالة
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الإجراءات
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredEmployees.map((employee) => (
                <tr key={employee.id} className="table-row">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center ml-4">
                        <User className="h-5 w-5 text-primary-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{employee.fullName}</div>
                        <div className="text-sm text-gray-500">{employee.department}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{employee.jobTitle}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{employee.salary.toLocaleString()}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{employee.phone}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {new Date(employee.hireDate).toLocaleDateString('ar-EG')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      employee.isActive 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {employee.isActive ? 'نشط' : 'غير نشط'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2 space-x-reverse">
                      <button 
                        onClick={() => handleViewEmployee(employee)}
                        className="text-blue-600 hover:text-blue-900"
                        title="عرض التفاصيل"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button 
                        className="text-amber-600 hover:text-amber-900"
                        title="تعديل"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button 
                        className="text-red-600 hover:text-red-900"
                        title="حذف"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Employee Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">إضافة موظف جديد</h2>
              <button 
                onClick={() => setShowAddForm(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>

            <form className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الاسم الكامل *
                  </label>
                  <input type="text" className="input-field" placeholder="أحمد محمد علي" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الرقم القومي *
                  </label>
                  <input type="text" className="input-field" placeholder="12345678901234" maxLength={14} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم الهاتف *
                  </label>
                  <input type="tel" className="input-field" placeholder="01234567890" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    البريد الإلكتروني
                  </label>
                  <input type="email" className="input-field" placeholder="ahmed@company.com" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    القسم *
                  </label>
                  <select className="input-field">
                    <option value="">اختر القسم</option>
                    {mockDepartments.map(dept => (
                      <option key={dept.id} value={dept.name}>{dept.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الوظيفة *
                  </label>
                  <select className="input-field">
                    <option value="">اختر الوظيفة</option>
                    <option value="مهندس مدني">مهندس مدني</option>
                    <option value="مهندس معماري">مهندس معماري</option>
                    <option value="عامل بناء">عامل بناء</option>
                    <option value="فني كهرباء">فني كهرباء</option>
                    <option value="محاسب">محاسب</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الراتب الأساسي (ج.م) *
                  </label>
                  <input type="number" className="input-field" placeholder="15000" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    تاريخ التوظيف *
                  </label>
                  <input type="date" className="input-field" defaultValue="2025-08-23" />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    فصيلة الدم
                  </label>
                  <select className="input-field">
                    <option value="">اختر فصيلة الدم</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم التأمين الاجتماعي
                  </label>
                  <input type="text" className="input-field" placeholder="INS123456" />
                </div>
              </div>

              <div className="flex justify-end space-x-3 space-x-reverse pt-6">
                <button 
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="btn-secondary"
                >
                  إلغاء
                </button>
                <button 
                  type="submit"
                  className="btn-primary"
                  onClick={(e) => {
                    e.preventDefault();
                    alert('تم إضافة الموظف بنجاح! سيتم إرسال إشعار ترحيبي عبر البريد الإلكتروني والـ SMS.');
                    setShowAddForm(false);
                  }}
                >
                  إضافة الموظف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Employee Details Modal */}
      {selectedEmployee && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">تفاصيل الموظف</h2>
              <button 
                onClick={() => setSelectedEmployee(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="h-16 w-16 bg-primary-100 rounded-full flex items-center justify-center">
                    <User className="h-8 w-8 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{selectedEmployee.fullName}</h3>
                    <p className="text-gray-600">{selectedEmployee.jobTitle}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <User className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">الرقم القومي</p>
                      <p className="text-sm text-gray-900">{selectedEmployee.nationalId}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 space-x-reverse">
                    <Phone className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">رقم الهاتف</p>
                      <p className="text-sm text-gray-900">{selectedEmployee.phone}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 space-x-reverse">
                    <Mail className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">البريد الإلكتروني</p>
                      <p className="text-sm text-gray-900">{selectedEmployee.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 space-x-reverse">
                    <Building2 className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">القسم</p>
                      <p className="text-sm text-gray-900">{selectedEmployee.department}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">معلومات العمل</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">الراتب الأساسي:</span>
                      <span className="text-sm font-medium">{selectedEmployee.salary.toLocaleString()} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">تاريخ التوظيف:</span>
                      <span className="text-sm font-medium">
                        {new Date(selectedEmployee.hireDate).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">فصيلة الدم:</span>
                      <span className="text-sm font-medium">{selectedEmployee.bloodType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">رقم التأمين:</span>
                      <span className="text-sm font-medium">{selectedEmployee.socialInsuranceNumber}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-3">الحسابات القانونية</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">التأمين الاجتماعي (14%):</span>
                      <span className="text-sm font-medium">{(selectedEmployee.salary * 0.14).toFixed(0)} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">تأمين الشركة (24%):</span>
                      <span className="text-sm font-medium">{(selectedEmployee.salary * 0.24).toFixed(0)} ج.م</span>
                    </div>
                    <div className="text-xs text-blue-600 mt-2">
                      * وفقاً لقانون العمل المصري رقم 14 لسنة 2025
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3 space-x-reverse pt-6">
              <button 
                onClick={() => setSelectedEmployee(null)}
                className="btn-secondary"
              >
                إغلاق
              </button>
              <button className="btn-primary">
                تعديل البيانات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Employees;

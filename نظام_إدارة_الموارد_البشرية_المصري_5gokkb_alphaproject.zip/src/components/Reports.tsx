import React, { useState } from 'react';
import { FileText, Download, Filter, Calendar, Building2 } from 'lucide-react';
import { mockReports, mockDepartments } from '../data/mockData';
import { Report } from '../types';

const Reports: React.FC = () => {
  const [reports] = useState<Report[]>(mockReports);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">التقارير</h1>
          <p className="text-gray-600 mt-1">إنشاء وتنزيل تقارير النظام</p>
        </div>
      </div>

      {/* Report Generation Card */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">إنشاء تقرير جديد</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">نوع التقرير</label>
            <select className="input-field">
              <option>تقرير الحضور</option>
              <option>تقرير الرواتب</option>
              <option>تقرير الإجازات</option>
              <option>تقرير المشاريع</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">القسم</label>
            <select className="input-field">
              <option value="">جميع الأقسام</option>
              {mockDepartments.map(dept => (
                <option key={dept.id} value={dept.name}>{dept.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">الفترة الزمنية</label>
            <div className="flex items-center">
              <input type="date" className="input-field rounded-l-none" />
              <span className="px-3 text-gray-500">إلى</span>
              <input type="date" className="input-field rounded-r-none" />
            </div>
          </div>
          <div className="flex space-x-2 space-x-reverse">
            <button className="btn-primary w-full flex items-center justify-center">
              <Download className="h-4 w-4 ml-2" />
              تصدير Excel
            </button>
            <button className="btn-primary w-full flex items-center justify-center">
              <FileText className="h-4 w-4 ml-2" />
              تصدير PDF
            </button>
          </div>
        </div>
      </div>

      {/* Generated Reports Table */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">التقارير التي تم إنشاؤها مؤخراً</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">عنوان التقرير</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">النوع</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">تاريخ الإنشاء</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">تم إنشاؤه بواسطة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {reports.map((report) => (
                <tr key={report.id} className="table-row">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{report.title}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{report.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(report.createdAt).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{report.generatedBy}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-primary-600 hover:text-primary-900 flex items-center">
                      <Download className="h-4 w-4 ml-1" />
                      تنزيل
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Reports;

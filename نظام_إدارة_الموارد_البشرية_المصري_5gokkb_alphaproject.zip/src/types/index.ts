export interface Employee {
  id: string;
  nationalId: string;
  fullName: string;
  phone: string;
  email: string;
  department: string;
  jobTitle: string;
  salary: number;
  hireDate: string;
  bloodType: string;
  socialInsuranceNumber: string;
  isActive: boolean;
  profileImage?: string;
}

export interface Department {
  id: string;
  name: string;
  head: string;
  employeeCount: number;
  budget: number;
}

export interface Attendance {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  checkIn?: string;
  checkOut?: string;
  workingHours: number;
  overtimeHours: number;
  status: 'حاضر' | 'غائب' | 'متأخر' | 'إجازة';
  location?: string;
}

export interface Payroll {
  id: string;
  employeeId: string;
  employeeName: string;
  month: string;
  basicSalary: number;
  overtimePay: number;
  socialInsurance: number;
  taxes: number;
  penalties: number;
  netSalary: number;
  workingDays: number;
  actualDays: number;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  type: 'اعتيادية' | 'مرضية' | 'أمومة' | 'حج' | 'طوارئ';
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'معلق' | 'موافق عليه' | 'مرفوض';
  appliedDate: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  location: string;
  startDate: string;
  endDate: string;
  budget: number;
  expenses: number;
  status: 'مخطط' | 'نشط' | 'متوقف' | 'مكتمل' | 'ملغى';
  projectManager: string;
  progress: number;
  tasks: ProjectTask[];
}

export interface ProjectTask {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  progress: number;
  assignedEmployees: string[];
  dependencies: string[];
  status: 'جديد' | 'قيد التنفيذ' | 'مكتمل' | 'متوقف';
}

export interface Report {
  id: string;
  title: string;
  type: 'حضور' | 'رواتب' | 'إجازات' | 'مشاريع' | 'امتثال';
  startDate: string;
  endDate: string;
  department?: string;
  generatedBy: string;
  createdAt: string;
  fileUrl?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  isRead: boolean;
  createdAt: string;
}

export interface LegalCompliance {
  socialInsuranceEmployeeRate: number;
  socialInsuranceCompanyRate: number;
  overtimeRate: number;
  nightOvertimeRate: number;
  holidayOvertimeRate: number;
  annualLeaveDays: number;
  materniteLeaveDays: number;
  hajjLeaveDays: number;
  absencePenaltyRate: number;
  law2025Enabled: boolean;
}

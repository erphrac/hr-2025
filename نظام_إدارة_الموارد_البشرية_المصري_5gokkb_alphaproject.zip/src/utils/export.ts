import { Employee, Payroll } from '../types';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { AmiriRegular } from './Amiri-Regular-font';
import { mockEmployees } from '../data/mockData';

// Extend jsPDF with autoTable
interface jsPDFWithAutoTable extends jsPDF {
  autoTable: (options: any) => jsPDF;
}

const exportToCsv = (filename: string, headers: string[], data: any[][]) => {
  const csvRows = [
    headers.join(','),
    ...data.map(row => 
      row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(',')
    )
  ];

  const csvString = '\uFEFF' + csvRows.join('\n'); // Add BOM for Excel to recognize UTF-8
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

const exportToPdf = (filename: string, title: string, headers: string[], data: any[][]) => {
  const doc = new jsPDF({ orientation: 'landscape' }) as jsPDFWithAutoTable;

  // Add Amiri font for Arabic support
  doc.addFileToVFS('Amiri-Regular.ttf', AmiriRegular);
  doc.addFont('Amiri-Regular.ttf', 'Amiri', 'normal');
  doc.setFont('Amiri');

  // Document Title
  doc.text(title, doc.internal.pageSize.getWidth() / 2, 15, { align: 'center' });
  doc.setFontSize(10);
  doc.text(`تاريخ التقرير: ${new Date().toLocaleDateString('ar-EG-u-nu-latn')}`, doc.internal.pageSize.getWidth() / 2, 22, { align: 'center' });

  // The 'autoTable' function is imported from 'jspdf-autotable'
  // and we've extended the jsPDF type to include it.
  doc.autoTable({
    head: [headers.reverse()], // Reverse for RTL
    body: data.map(row => row.map(item => String(item).split(' ').reverse().join(' ')).reverse()), // Reverse each row and its content for RTL
    startY: 30,
    theme: 'grid',
    styles: {
      font: 'Amiri',
      halign: 'right',
      cellPadding: 2,
      fontSize: 8,
    },
    headStyles: {
      fillColor: [2, 132, 199], // primary-600
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    didDrawPage: (data) => {
      // Footer
      const pageCount = doc.getNumberOfPages();
      doc.text(`صفحة ${data.pageNumber} من ${pageCount}`, data.settings.margin.left, doc.internal.pageSize.height - 10);
    }
  });

  doc.save(filename);
}

export const exportEmployeesToCsv = (filename: string, employees: Employee[]) => {
  if (!employees || employees.length === 0) {
    alert('لا يوجد بيانات لتصديرها.');
    return;
  }
  const headers = ['الموظف', 'الرقم القومي', 'الوظيفة', 'القسم', 'الهاتف', 'الراتب', 'تاريخ التوظيف', 'الحالة'];
  const data = employees.map(emp => [
    emp.fullName,
    emp.nationalId,
    emp.jobTitle,
    emp.department,
    emp.phone,
    emp.salary,
    emp.hireDate,
    emp.isActive ? 'نشط' : 'غير نشط'
  ]);
  exportToCsv(filename, headers, data);
};

export const exportEmployeesToPdf = (filename: string, employees: Employee[]) => {
  if (!employees || employees.length === 0) {
    alert('لا يوجد بيانات لتصديرها.');
    return;
  }
  const headers = ['الحالة', 'تاريخ التوظيف', 'الراتب (ج.م)', 'الهاتف', 'القسم', 'الوظيفة', 'الرقم القومي', 'الموظف'];
  const data = employees.map(emp => [
    emp.isActive ? 'نشط' : 'غير نشط',
    new Date(emp.hireDate).toLocaleDateString('ar-EG'),
    emp.salary.toLocaleString(),
    emp.phone,
    emp.department,
    emp.jobTitle,
    emp.nationalId,
    emp.fullName,
  ]);
  exportToPdf(filename, 'تقرير الموظفين', headers, data);
};

export const exportPayrollToCsv = (filename:string, payrollData: Payroll[]) => {
  if (!payrollData || payrollData.length === 0) {
    alert('لا يوجد بيانات لتصديرها.');
    return;
  }
  const headers = ['اسم الموظف', 'القسم', 'الراتب الأساسي', 'الإضافي', 'التأمينات', 'الضرائب', 'الغرامات', 'صافي الراتب'];
  const data = payrollData.map(p => {
    const employee = mockEmployees.find(e => e.id === p.employeeId);
    return [
      p.employeeName,
      employee?.department || 'غير محدد',
      p.basicSalary,
      p.overtimePay,
      p.socialInsurance,
      p.taxes,
      p.penalties,
      p.netSalary
    ];
  });
  exportToCsv(filename, headers, data);
};

export const exportPayrollToPdf = (filename: string, payrollData: Payroll[], reportTitle: string) => {
  if (!payrollData || payrollData.length === 0) {
    alert('لا يوجد بيانات لتصديرها.');
    return;
  }

  const headers = ['صافي الراتب', 'إجمالي الاستقطاعات', 'الإضافي', 'الراتب الأساسي', 'القسم', 'الموظف'];
  const data = payrollData.map(p => {
    const employee = mockEmployees.find(e => e.id === p.employeeId);
    const totalDeductions = p.socialInsurance + p.taxes + p.penalties;
    return [
      `${p.netSalary.toLocaleString()} ج.م`,
      `${totalDeductions.toLocaleString()} ج.م`,
      `${p.overtimePay.toLocaleString()} ج.م`,
      `${p.basicSalary.toLocaleString()} ج.م`,
      employee?.department || 'غير محدد',
      p.employeeName,
    ];
  });
  exportToPdf(filename, reportTitle, headers, data);
};

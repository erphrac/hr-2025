import { faker } from '@faker-js/faker/locale/ar';
import { Employee, Department, Attendance, Payroll, LeaveRequest, Project, ProjectTask, Report, Notification } from '../types';

// Mock Departments
export const mockDepartments: Department[] = [
  { id: '1', name: 'الإدارة العامة', head: 'أحمد محمد علي', employeeCount: 8, budget: 500000 },
  { id: '2', name: 'الهندسة', head: 'د. سارة محمود', employeeCount: 15, budget: 1200000 },
  { id: '3', name: 'المحاسبة والمالية', head: 'محمد أحمد', employeeCount: 6, budget: 400000 },
  { id: '4', name: 'العمالة والتشغيل', head: 'علي حسن', employeeCount: 25, budget: 800000 },
  { id: '5', name: 'اللوجستيات والتوريد', head: 'نورا عبدالله', employeeCount: 10, budget: 600000 },
  { id: '6', name: 'السلامة والصحة المهنية', head: 'خالد إبراهيم', employeeCount: 5, budget: 300000 },
];

// Egyptian names pool
const egyptianMaleNames = ['أحمد محمد', 'محمد أحمد', 'علي حسن', 'حسن علي', 'خالد إبراهيم', 'إبراهيم خالد', 'عمر محمود', 'محمود عمر', 'أسامة سامي', 'سامي أسامة'];
const egyptianFemaleNames = ['سارة محمود', 'نورا عبدالله', 'أميرة أحمد', 'دينا محمد', 'رانيا علي', 'مريم حسن', 'ندى خالد', 'رحاب إبراهيم', 'إيمان سامي', 'هبة محمود'];

// Job titles in Arabic
const jobTitles = {
  'الإدارة العامة': ['مدير عام', 'مساعد إداري', 'منسق', 'سكرتير'],
  'الهندسة': ['مهندس مدني', 'مهندس معماري', 'مهندس كهرباء', 'مشرف تنفيذ'],
  'المحاسبة والمالية': ['محاسب', 'مراجع حسابات', 'أمين صندوق', 'محلل مالي'],
  'العمالة والتشغيل': ['عامل بناء', 'فني كهرباء', 'سائق', 'حرفي'],
  'اللوجستيات والتوريد': ['مسؤول مخازن', 'منسق مشتريات', 'مشرف نقل', 'مراقب جودة'],
  'السلامة والصحة المهنية': ['مهندس سلامة', 'مفتش سلامة', 'طبيب شركة', 'أخصائي إسعافات'],
};

// Generate mock employees
export const mockEmployees: Employee[] = [];

mockDepartments.forEach(dept => {
  const deptJobTitles = jobTitles[dept.name as keyof typeof jobTitles] || ['موظف'];
  
  for (let i = 0; i < dept.employeeCount; i++) {
    const isGirl = Math.random() > 0.7;
    const names = isGirl ? egyptianFemaleNames : egyptianMaleNames;
    const name = names[Math.floor(Math.random() * names.length)];
    
    // Generate Egyptian National ID (14 digits)
    const nationalId = `${faker.number.int({ min: 10000000000000, max: 99999999999999 })}`;
    
    const employee: Employee = {
      id: faker.string.uuid(),
      nationalId,
      fullName: name,
      phone: `01${faker.number.int({ min: 100000000, max: 999999999 }).toString().padStart(9, '0')}`,
      email: `${name.split(' ')[0]}@company.com`,
      department: dept.name,
      jobTitle: deptJobTitles[Math.floor(Math.random() * deptJobTitles.length)],
      salary: faker.number.int({ min: 3000, max: 25000 }),
      hireDate: faker.date.between({ from: '2020-01-01', to: '2025-08-23' }).toISOString().split('T')[0],
      bloodType: faker.helpers.arrayElement(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']),
      socialInsuranceNumber: `INS${faker.number.int({ min: 100000, max: 999999 })}`,
      isActive: Math.random() > 0.05, // 95% active
    };
    
    mockEmployees.push(employee);
  }
});

// Generate mock attendance data for today (23/08/2025)
export const mockAttendance: Attendance[] = mockEmployees.map(emp => {
  const isPresent = Math.random() > 0.1; // 90% attendance rate
  const isLate = isPresent ? Math.random() > 0.8 : false; // 20% late if present
  
  const checkInHour = isLate ? 
    faker.number.int({ min: 8, max: 9 }) : 
    faker.number.int({ min: 7, max: 8 });
  const checkInMinute = faker.number.int({ min: 0, max: 59 });
  
  const workingHours = isPresent ? 
    faker.number.float({ min: 7, max: 10, precision: 0.5 }) : 0;
  
  const overtimeHours = workingHours > 8 ? workingHours - 8 : 0;
  
  let status: Attendance['status'] = 'غائب';
  if (isPresent) {
    if (isLate) status = 'متأخر';
    else status = 'حاضر';
  }
  
  return {
    id: faker.string.uuid(),
    employeeId: emp.id,
    employeeName: emp.fullName,
    date: '2025-08-23',
    checkIn: isPresent ? `${checkInHour.toString().padStart(2, '0')}:${checkInMinute.toString().padStart(2, '0')}` : undefined,
    checkOut: isPresent ? `${(checkInHour + Math.floor(workingHours)).toString().padStart(2, '0')}:${Math.floor((checkInMinute + (workingHours % 1) * 60)).toString().padStart(2, '0')}` : undefined,
    workingHours: workingHours,
    overtimeHours: Math.round(overtimeHours * 2) / 2,
    status,
    location: isPresent ? (Math.random() > 0.8 ? 'موقع العاصمة الإدارية' : 'المكتب الرئيسي') : undefined,
  };
});

// Generate mock payroll data for August 2025
export const mockPayroll: Payroll[] = mockEmployees.map(emp => {
  const attendance = mockAttendance.find(a => a.employeeId === emp.id);
  const workingDays = 26; // Standard working days in month
  const actualDays = faker.number.int({ min: 22, max: 26 });
  const overtimeHours = attendance?.overtimeHours || 0;
  
  // Calculate according to Egyptian Labor Law 2025
  const basicSalary = emp.salary * (actualDays / workingDays);
  const overtimePay = overtimeHours * (emp.salary / (workingDays * 8)) * 1.35; // 35% overtime rate
  const socialInsurance = (basicSalary + overtimePay) * 0.14; // 14% employee contribution
  const taxes = basicSalary > 10000 ? (basicSalary - 10000) * 0.1 : 0; // Simple tax calculation
  const penalties = actualDays < workingDays ? emp.salary * (workingDays - actualDays) / 30 : 0; // Absence penalty
  const netSalary = basicSalary + overtimePay - socialInsurance - taxes - penalties;
  
  return {
    id: faker.string.uuid(),
    employeeId: emp.id,
    employeeName: emp.fullName,
    month: '2025-08',
    basicSalary: Math.round(basicSalary),
    overtimePay: Math.round(overtimePay),
    socialInsurance: Math.round(socialInsurance),
    taxes: Math.round(taxes),
    penalties: Math.round(penalties),
    netSalary: Math.round(netSalary),
    workingDays,
    actualDays,
  };
});

// Generate mock leave requests
export const mockLeaveRequests: LeaveRequest[] = [];
for (let i = 0; i < 20; i++) {
  const emp = faker.helpers.arrayElement(mockEmployees);
  const leaveTypes = ['اعتيادية', 'مرضية', 'أمومة', 'حج', 'طوارئ'] as const;
  const type = faker.helpers.arrayElement(leaveTypes);
  const startDate = faker.date.between({ from: '2025-09-01', to: '2025-12-31' });
  const days = type === 'أمومة' ? 90 : type === 'حج' ? 3 : faker.number.int({ min: 1, max: 21 });
  const endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + days);
  
  mockLeaveRequests.push({
    id: faker.string.uuid(),
    employeeId: emp.id,
    employeeName: emp.fullName,
    type,
    startDate: startDate.toISOString().split('T')[0],
    endDate: endDate.toISOString().split('T')[0],
    days,
    reason: type === 'مرضية' ? 'مرض' : type === 'حج' ? 'أداء فريضة الحج' : 'ظروف شخصية',
    status: faker.helpers.arrayElement(['معلق', 'موافق عليه', 'مرفوض']),
    appliedDate: faker.date.between({ from: '2025-08-01', to: '2025-08-23' }).toISOString().split('T')[0],
  });
}

// Generate mock projects
export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'مشروع العاصمة الإدارية الجديدة',
    description: 'مجمع سكني وإداري بالعاصمة الإدارية',
    location: 'العاصمة الإدارية الجديدة',
    startDate: '2025-01-01',
    endDate: '2025-12-31',
    budget: 50000000,
    expenses: 35000000,
    status: 'نشط',
    projectManager: 'د. سارة محمود',
    progress: 70,
    tasks: [],
  },
  {
    id: '2',
    name: 'برج سكني بالزمالك',
    description: 'برج سكني 20 طابق',
    location: 'الزمالك، القاهرة',
    startDate: '2024-06-01',
    endDate: '2025-05-31',
    budget: 25000000,
    expenses: 25000000,
    status: 'مكتمل',
    projectManager: 'أحمد محمد علي',
    progress: 100,
    tasks: [],
  },
  {
    id: '3',
    name: 'مجمع طبي بالإسكندرية',
    description: 'مستشفى ومراكز طبية متخصصة',
    location: 'الإسكندرية',
    startDate: '2025-03-01',
    endDate: '2026-02-28',
    budget: 30000000,
    expenses: 8000000,
    status: 'نشط',
    projectManager: 'خالد إبراهيم',
    progress: 25,
    tasks: [],
  },
];

// Generate mock project tasks
const taskNames = ['صب الخرسانة', 'تركيب الكهرباء', 'أعمال السباكة', 'أعمال التشطيب', 'تركيب الواجهات', 'أعمال الدهان'];

mockProjects.forEach(project => {
  const numTasks = faker.number.int({ min: 4, max: 8 });
  for (let i = 0; i < numTasks; i++) {
    const startDate = new Date(project.startDate);
    startDate.setDate(startDate.getDate() + (i * 30));
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + 25);
    
    const task: ProjectTask = {
      id: faker.string.uuid(),
      name: `${taskNames[i % taskNames.length]} - المرحلة ${i + 1}`,
      description: `تنفيذ ${taskNames[i % taskNames.length]} للمشروع`,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      progress: faker.number.int({ min: 0, max: 100 }),
      assignedEmployees: faker.helpers.arrayElements(
        mockEmployees.filter(e => e.department === 'العمالة والتشغيل' || e.department === 'الهندسة').map(e => e.fullName),
        { min: 2, max: 5 }
      ),
      dependencies: i > 0 ? [project.tasks[i - 1]?.id].filter(Boolean) : [],
      status: faker.helpers.arrayElement(['جديد', 'قيد التنفيذ', 'مكتمل', 'متوقف']),
    };
    
    project.tasks.push(task);
  }
});

// Generate mock reports
export const mockReports: Report[] = [
  {
    id: '1',
    title: 'تقرير حضور أغسطس 2025',
    type: 'حضور',
    startDate: '2025-08-01',
    endDate: '2025-08-31',
    department: 'جميع الأقسام',
    generatedBy: 'أحمد محمد علي',
    createdAt: '2025-08-23T10:30:00',
    fileUrl: '#',
  },
  {
    id: '2',
    title: 'كشف رواتب أغسطس 2025',
    type: 'رواتب',
    startDate: '2025-08-01',
    endDate: '2025-08-31',
    department: 'جميع الأقسام',
    generatedBy: 'محمد أحمد',
    createdAt: '2025-08-22T14:15:00',
    fileUrl: '#',
  },
  {
    id: '3',
    title: 'تقرير الإجازات - النصف الأول 2025',
    type: 'إجازات',
    startDate: '2025-01-01',
    endDate: '2025-06-30',
    department: 'جميع الأقسام',
    generatedBy: 'سارة محمود',
    createdAt: '2025-07-01T09:00:00',
    fileUrl: '#',
  },
];

// Generate mock notifications
export const mockNotifications: Notification[] = [
  {
    id: '1',
    title: 'انتهاء إجازة موظف',
    message: 'تنتهي إجازة أحمد محمد غداً 24/08/2025',
    type: 'warning',
    isRead: false,
    createdAt: '2025-08-23T08:00:00',
  },
  {
    id: '2',
    title: 'اكتمال كشف الرواتب',
    message: 'تم إنجاز حساب رواتب شهر أغسطس 2025 بنجاح',
    type: 'success',
    isRead: false,
    createdAt: '2025-08-23T07:30:00',
  },
  {
    id: '3',
    title: 'موظفين غائبين',
    message: '3 موظفين غائبين اليوم بدون إذن',
    type: 'error',
    isRead: true,
    createdAt: '2025-08-23T09:15:00',
  },
  {
    id: '4',
    title: 'مشروع متأخر',
    message: 'مشروع مجمع طبي بالإسكندرية متأخر عن الجدول بـ 3 أيام',
    type: 'warning',
    isRead: false,
    createdAt: '2025-08-23T11:00:00',
  },
];

// Legal compliance settings according to Egyptian Labor Law 2025
export const legalCompliance = {
  socialInsuranceEmployeeRate: 0.14, // 14%
  socialInsuranceCompanyRate: 0.24, // 24%
  overtimeRate: 1.35, // 35% additional
  nightOvertimeRate: 1.5, // 50% additional
  holidayOvertimeRate: 2.0, // 100% additional
  annualLeaveDays: 21, // 21 days after 6 months
  annualLeaveAfter10Years: 30, // 30 days after 10 years
  materniteLeaveDays: 90, // 90 days paid
  hajjLeaveDays: 3, // 3 days
  absencePenaltyRate: 1/30, // 1/30 of salary per day
  law2025Enabled: true,
};
